from math import *

def f1(x):
    return x**4+3*x-9

def f2(x):
    return 3*cos(x)-2-x

def f3(x):
    return x*exp(x)-7

def f4(x):
    return exp(x)-x-10

def f5(x):
    return 2*tan(x)-x-5

def f6(x):
    return exp(x)-x**2-3

def f7(x):
    return 3*x+4*log(x)-7

def f8(x):
    return x**4-2*x**2+4*x-17

def f9(x):
    return exp(x)-2*sin(x)-7

def f10(x):
    return log(x**2+4)*exp(x)-10



def fder1(x):
    return 4*x**3+3

def fder2(x):
    return -3*sin(x)-1

def fder3(x):
    return exp(x)+x*exp(x)

def fder4(x):
    return exp(x)-1

def fder5(x):
    return (2/(cos(x)**2)-1)

def fder6(x):
    return exp(x)-2*x

def fder7(x):
    return 3+4/x

def fder8(x):
    return 4*x**3-4*x+4

def fder9(x):
    return exp(x)-2*cos(x)

def fder10(x):
    return ((2*x)/(x**2+4))*exp(x)+log(x**2+4)*exp(x)



def Newton(f,fder,x0,epsilon,Nitermax):
    n=1
    xold=x0
    xnew=xold-f(xold)/fder(xold)
    erreur= abs(xnew-xold)
    print(erreur)
    while erreur > epsilon and n < Nitermax:
        xold=xnew
        xnew=xold-f(xold)/fder(xold)
        n=n+1
        erreur=abs(xnew-xold)

    return xnew,n

print(Newton(f1,fder1,3/4,1e-10,5e4))

    
